/**
 * ─────────────────────────────────────────────────────────────────────────────
 * DashboardEngine.jsx  (v7 — free-position, resizable panels — Bigin style)
 * ─────────────────────────────────────────────────────────────────────────────
 * Changes from v6:
 *   1. Replaced HTML5 drag-reorder with react-grid-layout:
 *        - panels can be dropped ANYWHERE on the canvas (free x/y), not just
 *          swapped into the existing flow order
 *        - panels are resizable from all 8 handles (corners + edges)
 *        - while dragging/resizing, faint grid cells render behind the panels
 *          so you can see exactly where a panel will land (the "indicator")
 *   2. Layout (x, y, w, h) is stored per-panel as panel.layout and persisted
 *      with the rest of the view, same as colSpan/rowSpan used to be.
 *      Old panels without a layout get one auto-generated on first load so
 *      nothing breaks for existing dashboards.
 *   3. "Add Panel" now drops the new panel into the first open grid space
 *      and the grid briefly highlights it so it's obvious where it landed.
 *
 * Requires: react-grid-layout  (npm install react-grid-layout)
 * ─────────────────────────────────────────────────────────────────────────────
 */

import React, {
  Suspense,
  memo,
  useCallback,
  useEffect,
  useMemo,
  useState,
  useRef,
} from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Responsive, WidthProvider } from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
import {
  LayoutDashboard, Pencil, Trash2, Copy, Maximize2, Printer,
  X as XIcon, GripVertical, Calendar,
} from "lucide-react";
import { resolveComponent } from "./kpiRegistry";
import {
  resolveSingleValue,
  resolveTrendSeries,
  resolveMapValue,
  resolveTableRows,
  resolveFrameworkTable,
  resolveByPath,
  isObjectMap,
} from "./dataExtractors";
import PanelBuilderModal from "./PanelBuilderModal";

const ResponsiveGridLayout = WidthProvider(Responsive);

const SINGLE_VIEW_ID    = "main";
const SINGLE_VIEW_LABEL = "Dashboard";

// ─── grid constants ───────────────────────────────────────────────────────────
// 12-column grid, 80px row height — matches the density of the Bigin reference
// (roughly 4-5 small KPI cards per row on a desktop viewport).
const GRID_COLS    = { lg: 12, md: 12, sm: 6, xs: 4 };
const GRID_BREAKS  = { lg: 1024, md: 768, sm: 480, xs: 0 };
const ROW_HEIGHT   = 80;
const DEFAULT_W    = 3;   // ~quarter width on lg
const DEFAULT_H    = 3;   // ~240px tall

// ─── layout helpers ───────────────────────────────────────────────────────────

// A panel below this size renders as an unusable sliver (this is what was
// happening — a saved layout with w:1 produces a ~40-60px-wide card with no
// room for its content, which looks like a "blank" card). Every layout read
// from storage and every layout written back to storage is clamped to this.
//
// Chart-family widgets (line/bar/area/donut) need more room than a StatCard
// or TargetMeter — they have axis labels, legends, and a Recharts
// ResponsiveContainer that can render nothing visible if squeezed too far.
// So minimums are per-componentType, not one global floor.
const MIN_W = 2;
const MIN_H = 3;

const CHART_TYPES = new Set([
  "TrendLineChart", "TrendAreaChart", "TrendBarChart", "DonutStatusChart",
]);

// ─── per-panel duration ─────────────────────────────────────────────────────
// Each panel now carries its own date window (panel.interval), independent
// of any page-level selector. Defaults to 7 Days when a panel doesn't have
// one yet (e.g. existing saved panels from before this feature).
const PANEL_INTERVALS = [
  { key: "7d",     label: "7D"  },
  { key: "14d",    label: "14D" },
  { key: "90d",    label: "90D" },
  { key: "custom", label: "Custom" },
];
const DEFAULT_PANEL_INTERVAL = { key: "7d", customFrom: "", customTo: "" };

function ensurePanelInterval(panel) {
  return panel.interval?.key ? panel.interval : DEFAULT_PANEL_INTERVAL;
}

// ─── panel identity (for duplicate detection) ────────────────────────────────
// Two panels count as "the same panel" if they're the same component type
// showing the same underlying data field(s) — not by generated id/title,
// since templates instantiate fresh ids every time. Trend-type panels are
// keyed by their full set of series extractors (order-independent); single-
// value panels are keyed by their extractor.
function panelSignature(panel) {
  const props = panel.props ?? {};
  if (Array.isArray(props.series) && props.series.length) {
    const extractors = props.series.map((s) => s.extractor).filter(Boolean).sort().join("|");
    return `${panel.componentType}::${extractors}`;
  }
  return `${panel.componentType}::${props.extractor ?? ""}`;
}

function minSizeFor(componentType) {
  if (CHART_TYPES.has(componentType)) return { minW: 4, minH: 4 };
  if (componentType === "TableWidget") return { minW: 4, minH: 4 };
  return { minW: MIN_W, minH: MIN_H }; // StatCard, ScoreGauge, TargetMeter, DepartmentBreakdown
}

function clampLayout({ x, y, w, h }, componentType) {
  const { minW, minH } = minSizeFor(componentType);
  const safeW = Math.max(Number(w) || DEFAULT_W, minW);
  const safeH = Math.max(Number(h) || DEFAULT_H, minH);
  return {
    x: Math.max(Number(x) || 0, 0),
    y: Math.max(Number(y) || 0, 0),
    w: safeW,
    h: safeH,
  };
}

/** Convert legacy colSpan/rowSpan (or nothing at all) into a layout item. */
function ensureLayout(panel, fallbackIndex = 0) {
  if (panel.layout?.w && panel.layout?.h) return clampLayout(panel.layout, panel.componentType);
  const { minW } = minSizeFor(panel.componentType);
  const w = Math.max(Math.min((panel.colSpan ?? 1) * 3, GRID_COLS.lg), minW);
  const h = Math.max((panel.rowSpan ?? 1) * 3, minSizeFor(panel.componentType).minH);
  // Stack new/legacy panels in a simple left-to-right, top-to-bottom flow
  // on first run — react-grid-layout's collision detection takes over after.
  const perRow = Math.floor(GRID_COLS.lg / w) || 1;
  const x = (fallbackIndex % perRow) * w;
  const y = Math.floor(fallbackIndex / perRow) * h;
  return clampLayout({ x, y, w, h }, panel.componentType);
}

/** Find the first open x/y slot for a brand-new panel of size w×h. */
function findOpenSlot(layouts, w = DEFAULT_W, h = DEFAULT_H) {
  const cols = GRID_COLS.lg;
  const occupied = layouts.map((l) => ({ x: l.x, y: l.y, w: l.w, h: l.h }));
  const maxY = occupied.reduce((m, l) => Math.max(m, l.y + l.h), 0);
  for (let y = 0; y <= maxY + h; y++) {
    for (let x = 0; x <= cols - w; x++) {
      const collides = occupied.some(
        (l) => x < l.x + l.w && x + w > l.x && y < l.y + l.h && y + h > l.y
      );
      if (!collides) return { x, y, w, h };
    }
  }
  return { x: 0, y: maxY, w, h };
}

// ─── data resolution ──────────────────────────────────────────────────────────
function resolveKpiData(kpiConfig, result) {
  const { componentType, props = {} } = kpiConfig;
  switch (componentType) {
    case "StatCard":
    case "ScoreGauge":
    case "TargetMeter": {
      const extractor = props.extractor ?? kpiConfig.extractor ?? "";
      return resolveSingleValue(result, extractor);
    }
    case "TrendLineChart":
    case "TrendAreaChart":
    case "TrendBarChart": {
      return resolveTrendSeries(result, props.series ?? [], props.labelExtractor);
    }
    case "DonutStatusChart":
    case "DepartmentBreakdown": {
      const extractor = props.extractor ?? kpiConfig.extractor ?? "";
      if (props.staticSlices) return { slices: props.staticSlices };
      return resolveMapValue(result, extractor);
    }
    case "TableWidget": {
      const extractor = props.extractor ?? kpiConfig.extractor ?? "";
      const raw = resolveByPath(result?.data, extractor);
      if (isObjectMap(raw)) {
        return resolveFrameworkTable(result, extractor);
      }
      return resolveTableRows(result, extractor);
    }
    default:
      return {};
  }
}

// ─── KpiWrapper ───────────────────────────────────────────────────────────────
const KpiWrapper = memo(function KpiWrapper({ kpiConfig, results, comparisonResults, loading }) {
  const Component = useMemo(() => resolveComponent(kpiConfig.componentType), [kpiConfig.componentType]);

  const result = useMemo(() => {
    if (!results?.length) return null;
    const reportId = kpiConfig.reportId;
    if (!reportId) return results[0] ?? null;
    return results.find((r) => r?.reportId === reportId) ?? results[0] ?? null;
  }, [results, kpiConfig.reportId]);

  const compResult = useMemo(() => comparisonResults?.[0] ?? null, [comparisonResults]);

  const resolvedData = useMemo(() => {
    if (!result) return null;
    try { return resolveKpiData(kpiConfig, result); } catch { return null; }
  }, [result, kpiConfig]);

  const comparisonData = useMemo(() => {
    if (!compResult) return null;
    try { return resolveKpiData(kpiConfig, compResult); } catch { return null; }
  }, [compResult, kpiConfig]);

  return (
    <Suspense fallback={<SkeletonCard />}>
      <Component
        kpiConfig={kpiConfig}
        resolvedData={resolvedData}
        comparisonData={comparisonData}
        loading={loading || !result}
      />
    </Suspense>
  );
});

// ─── SkeletonCard ─────────────────────────────────────────────────────────────
function SkeletonCard() {
  return (
    <div className="h-full rounded-2xl bg-slate-50 animate-pulse flex flex-col gap-3 p-5">
      <div className="h-3 w-1/3 bg-slate-200 rounded-full" />
      <div className="flex-1 bg-slate-100 rounded-xl" />
    </div>
  );
}

// ─── Per-panel duration picker ────────────────────────────────────────────────
// The 7D / 14D / 90D / Custom control used to live once, globally, in the
// page header. It now lives per-panel so each panel can window its own data
// independently. `value` is panel.interval ({ key, customFrom, customTo }).
function IntervalPicker({ value, onChange, compact = false }) {
  const interval = value?.key ?? DEFAULT_PANEL_INTERVAL.key;
  const customFrom = value?.customFrom ?? "";
  const customTo = value?.customTo ?? "";
  const [showCustom, setShowCustom] = useState(false);

  const selectKey = (key) => {
    if (key === "custom") {
      setShowCustom((v) => !v);
      onChange({ key: "custom", customFrom, customTo });
      return;
    }
    setShowCustom(false);
    onChange({ key, customFrom: "", customTo: "" });
  };

  return (
    <div className="relative" data-html2canvas-ignore="true">
      <div className={`flex bg-slate-100 rounded-lg p-0.5 gap-0.5 ${compact ? "" : "scale-95"}`}>
        {PANEL_INTERVALS.map((opt) => (
          <button
            key={opt.key}
            onClick={(e) => { e.stopPropagation(); selectKey(opt.key); }}
            className={`px-1.5 py-1 rounded-md text-[10px] font-bold transition-all flex items-center gap-0.5 ${
              interval === opt.key ? "bg-white text-slate-800 shadow-sm" : "text-slate-400 hover:text-slate-600"
            }`}
          >
            {opt.key === "custom" && <Calendar size={9} />}
            {opt.label}
          </button>
        ))}
      </div>

      <AnimatePresence>
        {showCustom && interval === "custom" && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.12 }}
            onClick={(e) => e.stopPropagation()}
            className="absolute right-0 top-full mt-1 z-20 bg-white rounded-xl border border-slate-200 shadow-lg p-2.5 flex items-center gap-1.5 whitespace-nowrap"
          >
            <input
              type="date"
              value={customFrom}
              onChange={(e) => onChange({ key: "custom", customFrom: e.target.value, customTo })}
              className="text-[10px] border border-slate-200 rounded-md px-1.5 py-1 bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-300"
            />
            <span className="text-[10px] text-slate-300">–</span>
            <input
              type="date"
              value={customTo}
              min={customFrom}
              onChange={(e) => onChange({ key: "custom", customFrom, customTo: e.target.value })}
              className="text-[10px] border border-slate-200 rounded-md px-1.5 py-1 bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-300"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Fullscreen overlay ───────────────────────────────────────────────────────
// Portaled to document.body: without this, the overlay renders nested inside
// several ancestors that get an inline CSS `transform` from framer-motion
// (the canvas's animated motion.div). Once any ancestor has a transform,
// `position: fixed` descendants are positioned relative to THAT ancestor
// instead of the viewport — so instead of a true fullscreen modal, this was
// rendering clipped down to the size of the small panel card it lived in
// (the empty white box seen in testing). Portaling escapes that subtree
// entirely, the same way the panel builder / other modals already do
// implicitly by living at the page root.
function FullscreenOverlay({ panel, results, comparisonResults, loading, onClose }) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.18 }}
        className="relative bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden"
        style={{ maxHeight: "85vh" }}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors"
        >
          <XIcon size={14} className="text-slate-500" />
        </button>
        <div className="p-6" style={{ minHeight: 380 }}>
          <KpiWrapper
            kpiConfig={panel}
            results={results}
            comparisonResults={comparisonResults}
            loading={loading}
          />
        </div>
      </motion.div>
    </div>,
    document.body
  );
}

// ─── Panel card ───────────────────────────────────────────────────────────────
// Note: no draggable/onDrag* props here anymore — react-grid-layout's
// DraggableCore wraps this whole element from the outside and listens for
// mousedown on the .drag-handle element. Resize handles are injected by RGL
// itself (see resizeHandles + handle classNames in styles below).
const PanelCard = memo(function PanelCard({
  panel, results, comparisonResults, loading,
  onEdit, onDelete, onClone, onIntervalChange, justAdded,
}) {
  const [fullscreen, setFullscreen] = useState(false);
  const printRef = useRef(null);

  const handlePrint = () => {
    if (!printRef.current) return;
    const w = window.open("", "_blank", "width=800,height=600");
    w.document.write(`
      <html><head><title>CalVant Panel — ${panel.title}</title>
      <link rel="stylesheet" href="${window.location.origin}/index.css">
      </head><body style="padding:32px;font-family:Segoe UI,sans-serif">
      <h3 style="color:#475569;font-size:13px;margin-bottom:16px">${panel.title}</h3>
      ${printRef.current.innerHTML}
      </body></html>
    `);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 400);
  };

  return (
    <>
      <div
        className={`relative h-full w-full rounded-2xl bg-white shadow-sm border transition-shadow overflow-hidden group ${
          justAdded
            ? "border-indigo-400 ring-2 ring-indigo-200"
            : "border-slate-100"
        }`}
      >
        {/* Drag handle — visible on hover, the only grab point so chart
            interactions (hover tooltips, scroll) keep working normally */}
        <div
          className="drag-handle absolute top-2 left-2 z-10 opacity-0 group-hover:opacity-100
            transition-opacity cursor-grab active:cursor-grabbing p-1 rounded-lg
            text-slate-300 hover:text-slate-500 hover:bg-slate-50"
        >
          <GripVertical size={14} />
        </div>

        {/* Per-panel duration picker — top-left, next to the drag handle */}
        <div className="absolute top-2 left-8 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
          <IntervalPicker value={ensurePanelInterval(panel)} onChange={onIntervalChange} />
        </div>

        {/* Action bar */}
        <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5 bg-white/90 backdrop-blur-sm rounded-xl border border-slate-100 shadow-sm px-1 py-0.5">
          <ActionBtn icon={Pencil}    title="Edit"       onClick={onEdit}                 color="indigo" />
          <ActionBtn icon={Copy}      title="Clone"      onClick={onClone}                color="amber"  />
          <ActionBtn icon={Maximize2} title="Fullscreen" onClick={() => setFullscreen(true)} color="sky" />
          <ActionBtn icon={Printer}   title="Print"      onClick={handlePrint}            color="slate"  />
          <div className="w-px h-4 bg-slate-200 mx-0.5" />
          <ActionBtn icon={Trash2}    title="Delete"     onClick={onDelete}               color="rose"   />
        </div>

        {/* Panel content */}
        <div ref={printRef} className="h-full w-full overflow-hidden">
          <KpiWrapper
            kpiConfig={panel}
            results={results}
            comparisonResults={comparisonResults}
            loading={loading}
          />
        </div>
      </div>

      {/* Fullscreen */}
      <AnimatePresence>
        {fullscreen && (
          <FullscreenOverlay
            panel={panel}
            results={results}
            comparisonResults={comparisonResults}
            loading={loading}
            onClose={() => setFullscreen(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
});

function ActionBtn({ icon: Icon, title, onClick, color }) {
  const colors = {
    indigo: "hover:bg-indigo-50 hover:text-indigo-600",
    amber:  "hover:bg-amber-50  hover:text-amber-600",
    sky:    "hover:bg-sky-50    hover:text-sky-600",
    slate:  "hover:bg-slate-100 hover:text-slate-700",
    rose:   "hover:bg-rose-50   hover:text-rose-600",
  };
  return (
    <button
      onClick={onClick}
      title={title}
      className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors text-slate-400 ${colors[color] || ""}`}
    >
      <Icon size={11} />
    </button>
  );
}

// ─── EmptyCanvas ──────────────────────────────────────────────────────────────
function EmptyCanvas({ onAddPanel }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-50 to-blue-50 flex items-center justify-center shadow-inner">
        <LayoutDashboard size={26} className="text-indigo-300" />
      </div>
      <div>
        <p className="text-sm font-semibold text-slate-600 mb-1">No panels yet</p>
        <p className="text-xs text-slate-400 max-w-xs">
          Click <strong className="text-indigo-500">+ Add Panel</strong> to add a KPI, chart, or target meter.
        </p>
      </div>
      <button
        onClick={onAddPanel}
        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors shadow-sm"
      >
        <span className="text-sm leading-none">＋</span> Add first panel
      </button>
    </div>
  );
}

// ─── DashboardEngine ──────────────────────────────────────────────────────────
export default function DashboardEngine({
  dashboardName,
  customViews = [],
  activeViewId,
  onCustomViewsChange,
  results,
  comparisonResults = [],
  getComparisonForWindow,
  getResultsForWindow,
  loading,
  viewsLoading = false,
  error,
  userRole = "",
}) {
  const [showBuilder,  setShowBuilder]  = useState(false);
  const [editingPanel, setEditingPanel] = useState(null);
  const [isDragging,   setIsDragging]   = useState(false); // shows grid-cell indicator
  const [justAddedId,  setJustAddedId]  = useState(null);

  // Set (synchronously, during render, inside the panelsWithLayout useMemo
  // below) when colliding/overlapping saved layouts were detected and
  // auto-repaired. The effect right after persists that repaired layout
  // back to the backend exactly once, so a corrupted save (e.g. every panel
  // stuck at x:0) self-heals on next load instead of repeating forever.
  const needsLayoutRepairRef = useRef(null);

  const view = customViews.find((v) => v.id === activeViewId) ?? customViews[0] ?? null;

  // ── single source of truth for writing a view back out ───────────────────
  // Every mutation (add/edit/delete/clone panel, layout change, interval
  // change, layout repair) must update ONLY the active view inside the FULL
  // customViews array — never replace the whole array with a single view,
  // or every other view gets dropped both from local state and from the
  // backend (saveScheduleViewsRemote does a full-replace PUT).
  const pushViewUpdate = useCallback((updatedView) => {
    const exists = customViews.some((v) => v.id === updatedView.id);
    const nextViews = exists
      ? customViews.map((v) => (v.id === updatedView.id ? updatedView : v))
      : [...customViews, updatedView];
    onCustomViewsChange?.(nextViews);
  }, [customViews, onCustomViewsChange]);

  // ── normalise: make sure every panel has a layout (x,y,w,h) ──────────────
  // Repairs two bad states from saved data:
  //   1. True overlaps — two panels' saved x/y/w/h boxes intersect.
  //   2. "Single column" — every panel shares the same x (e.g. all x:0,
  //      stacked only in y). This isn't an overlap, but it's just as broken:
  //      it means every panel was placed via findOpenSlot() against an empty
  //      board (a stale-closure bug, fixed below in savePanel/etc — this
  //      repairs data that was already saved before that fix).
  // Either case triggers a full re-flow into open grid slots, left-to-right
  // top-to-bottom, instead of trusting the corrupted saved coordinates.
  const panelsWithLayout = useMemo(() => {
    if (!view?.panels?.length) return [];
    const withLayout = view.panels.map((p, i) => ({ ...p, layout: ensureLayout(p, i) }));

    const distinctX = new Set(withLayout.map((p) => p.layout.x));
    const allSameColumn = withLayout.length > 1 && distinctX.size === 1;

    const hasOverlap = withLayout.some((p, i) =>
      withLayout.some((q, j) => i !== j &&
        p.layout.x < q.layout.x + q.layout.w && p.layout.x + p.layout.w > q.layout.x &&
        p.layout.y < q.layout.y + q.layout.h && p.layout.y + p.layout.h > q.layout.y
      )
    );

    if (!allSameColumn && !hasOverlap) return withLayout;

    // Re-flow everything fresh, in saved order, left-to-right top-to-bottom.
    const placed = [];
    for (const p of withLayout) {
      const occupied = placed.map((q) => ({ x: q.layout.x, y: q.layout.y, w: q.layout.w, h: q.layout.h }));
      const slot = findOpenSlot(occupied, p.layout.w, p.layout.h);
      placed.push({ ...p, layout: slot });
    }
    needsLayoutRepairRef.current = placed;
    return placed;
  }, [view]);

  const rglLayout = useMemo(
    () => panelsWithLayout.map((p) => {
      const { minW, minH } = minSizeFor(p.componentType);
      return { i: p.id, x: p.layout.x, y: p.layout.y, w: p.layout.w, h: p.layout.h, minW, minH };
    }),
    [panelsWithLayout]
  );

  // ── per-panel comparison windows ──────────────────────────────────────────
  // Each panel can carry its own panel.comparison = { enabled, from, to },
  // set via PanelBuilderModal's ComparisonSection. When present, resolve that
  // panel's comparison data independently using getComparisonForWindow rather
  // than falling back to the single global ComparisonBar window — otherwise
  // every panel would just show (or not show) the same comparison regardless
  // of what was configured for it individually.
  const comparisonResultsByPanel = useMemo(() => {
    const map = {};
    for (const p of panelsWithLayout) {
      if (p.comparison?.enabled && p.comparison?.from) {
        map[p.id] = typeof getComparisonForWindow === "function"
          ? getComparisonForWindow(p.comparison.from, p.comparison.to)
          : [];
      } else {
        map[p.id] = comparisonResults;
      }
    }
    return map;
  }, [panelsWithLayout, getComparisonForWindow, comparisonResults]);

  // ── per-panel duration windows ────────────────────────────────────────────
  // The 7D/14D/90D/Custom selector used to be one global control; now every
  // panel carries its own panel.interval and is windowed independently via
  // getResultsForWindow, instead of all panels sharing the single `results`
  // computed from the page-level filters.
  const resultsByPanel = useMemo(() => {
    const map = {};
    for (const p of panelsWithLayout) {
      const interval = ensurePanelInterval(p);
      map[p.id] = typeof getResultsForWindow === "function"
        ? getResultsForWindow(interval.key, interval.customFrom, interval.customTo)
        : results;
    }
    return map;
  }, [panelsWithLayout, getResultsForWindow, results]);

  // ── persist the auto-repaired layout (see panelsWithLayout above) ────────
  // Runs after render, exactly once per repair, so the corrected x/y values
  // get written back through the normal PUT .../views path instead of
  // silently re-repairing in memory on every load.
  useEffect(() => {
    if (!needsLayoutRepairRef.current || !view) return;
    const repairedPanels = needsLayoutRepairRef.current;
    needsLayoutRepairRef.current = null;
    pushViewUpdate({ ...view, panels: repairedPanels.map(({ layout, ...rest }) => ({ ...rest, layout })) });
  }, [panelsWithLayout, view, pushViewUpdate]);

  // ── always-fresh occupied layout, computed directly from view.panels ─────
  // (NOT from the memoized rglLayout — that can be one render behind if two
  // saves happen back-to-back, e.g. clicking "Add Panel" twice quickly, or
  // editing then immediately adding. Reading straight from view.panels here
  // means every save sees the real current board, never a stale one.)
  const currentOccupiedLayout = useCallback(() => {
    if (!view?.panels?.length) return [];
    return view.panels.map((p, i) => {
      const l = ensureLayout(p, i);
      return { i: p.id, x: l.x, y: l.y, w: l.w, h: l.h };
    });
  }, [view]);

  // ── persist a new layout back onto the panels ────────────────────────────
  const commitLayout = useCallback((layout) => {
    if (!view) return;
    const byId = Object.fromEntries(layout.map((l) => [l.i, l]));
    const updatedPanels = view.panels.map((p) => {
      const l = byId[p.id];
      if (!l) return p;
      return { ...p, layout: clampLayout({ x: l.x, y: l.y, w: l.w, h: l.h }, p.componentType) };
    });
    pushViewUpdate({ ...view, panels: updatedPanels });
  }, [view, pushViewUpdate]);

  // ── save panel (create / edit) ────────────────────────────────────────────
  const savePanel = useCallback(({ panel, isEdit, originalPanelId }) => {
    let updatedView;
    if (view) {
      if (isEdit && originalPanelId) {
        updatedView = { ...view, panels: view.panels.map((p) => (p.id === originalPanelId ? { ...panel, layout: p.layout } : p)) };
      } else {
        const { minW, minH } = minSizeFor(panel.componentType);
        const slot = findOpenSlot(currentOccupiedLayout(), minW, minH);
        const newPanel = { ...panel, layout: slot };
        updatedView = { ...view, panels: [...view.panels, newPanel] };
        setJustAddedId(panel.id);
      }
    } else {
      const { minW, minH } = minSizeFor(panel.componentType);
      const newPanel = { ...panel, layout: { x: 0, y: 0, w: minW, h: minH } };
      updatedView = { id: SINGLE_VIEW_ID, label: SINGLE_VIEW_LABEL, panels: [newPanel] };
      setJustAddedId(panel.id);
    }
    pushViewUpdate(updatedView);
  }, [view, currentOccupiedLayout, pushViewUpdate]);

  // ── append template panels ────────────────────────────────────────────────
  // Skips any incoming panel whose signature (componentType + data field)
  // already exists on the dashboard, so applying the same template twice — or
  // two templates that overlap (e.g. both have a "Risks · Total" stat) — no
  // longer produces visible duplicate panels. skippedCount is returned so the
  // caller can let the user know if anything was filtered out.
  const appendTemplatePanels = useCallback((panels) => {
    const existingSignatures = new Set((view?.panels ?? []).map(panelSignature));
    const deduped = [];
    for (const p of panels) {
      const sig = panelSignature(p);
      if (existingSignatures.has(sig)) continue; // already on the dashboard
      existingSignatures.add(sig); // also dedupe within the same template
      deduped.push(p);
    }
    const skippedCount = panels.length - deduped.length;

    if (deduped.length === 0) return { addedCount: 0, skippedCount };

    let runningLayout = currentOccupiedLayout();
    const placed = deduped.map((p) => {
      const { minW, minH } = minSizeFor(p.componentType);
      const slot = findOpenSlot(runningLayout, minW, minH);
      runningLayout = [...runningLayout, { i: p.id, ...slot }];
      return { ...p, layout: slot };
    });
    const updatedView = view
      ? { ...view, panels: [...view.panels, ...placed] }
      : { id: SINGLE_VIEW_ID, label: SINGLE_VIEW_LABEL, panels: placed };
    pushViewUpdate(updatedView);
    return { addedCount: placed.length, skippedCount };
  }, [view, currentOccupiedLayout, pushViewUpdate]);

  // ── delete panel ──────────────────────────────────────────────────────────
  const deletePanel = useCallback((panelId) => {
    if (!view) return;
    pushViewUpdate({ ...view, panels: view.panels.filter((p) => p.id !== panelId) });
  }, [view, pushViewUpdate]);

  // ── clone panel ───────────────────────────────────────────────────────────
  const clonePanel = useCallback((panel) => {
    if (!view) return;
    const { minW, minH } = minSizeFor(panel.componentType);
    const slot = findOpenSlot(currentOccupiedLayout(), panel.layout?.w ?? minW, panel.layout?.h ?? minH);
    const cloned = { ...panel, id: `custom_panel_clone_${Date.now()}`, title: `${panel.title} (Copy)`, layout: slot };
    pushViewUpdate({ ...view, panels: [...view.panels, cloned] });
  }, [view, currentOccupiedLayout, pushViewUpdate]);

  // ── update a single panel's duration (7D/14D/90D/Custom) ───────────────────
  const updatePanelInterval = useCallback((panelId, interval) => {
    if (!view) return;
    pushViewUpdate({
      ...view,
      panels: view.panels.map((p) => (p.id === panelId ? { ...p, interval } : p)),
    });
  }, [view, pushViewUpdate]);

  // ── clear the "just added" highlight after a moment ───────────────────────
  useEffect(() => {
    if (!justAddedId) return;
    const t = setTimeout(() => setJustAddedId(null), 2200);
    return () => clearTimeout(t);
  }, [justAddedId]);

  if (error) {
    return (
      <div className="p-8 text-center text-rose-500 text-sm">
        Failed to load dashboard data: {error}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Toolbar */}
      <div
        id="kpis-container"
        data-html2canvas-ignore="true"
        className="flex items-center justify-between"
      >
        <div>
          {dashboardName && (
            <h2 className="text-sm font-bold text-slate-700">{dashboardName}</h2>
          )}
          {panelsWithLayout.length > 0 && (
            <p className="text-xs text-slate-400 mt-0.5">
              {panelsWithLayout.length} panel{panelsWithLayout.length !== 1 ? "s" : ""}{" "}
              <span className="text-slate-300">· drag the grip to move · drag a corner to resize</span>
            </p>
          )}
        </div>

        <button
          onClick={() => { setEditingPanel(null); setShowBuilder(true); }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white
            text-sm font-semibold hover:bg-indigo-700 active:scale-95 transition-all shadow-sm"
        >
          <span className="text-base leading-none">＋</span>
          <span className="whitespace-nowrap">Add Panel</span>
        </button>
      </div>

      {/* Canvas */}
      <AnimatePresence mode="wait">
        <motion.div
          id="charts-container"
          key={viewsLoading ? "views-loading" : "main"}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.18 }}
        >
          {viewsLoading ? (
            <div className="mt-2 grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))" }}>
              {[1, 2, 3].map((i) => (
                <div key={i} className="rounded-2xl bg-white border border-slate-100 shadow-sm p-5 flex flex-col gap-3 animate-pulse">
                  <div className="h-3 w-1/3 bg-slate-100 rounded-full" />
                  <div className="h-32 bg-slate-50 rounded-xl" />
                </div>
              ))}
            </div>
          ) : !view || panelsWithLayout.length === 0 ? (
            <EmptyCanvas onAddPanel={() => setShowBuilder(true)} />
          ) : (
            <div
              className={`relative mt-2 rounded-2xl overflow-hidden transition-colors ${
                isDragging ? "bg-grid-indicator" : ""
              }`}
            ><div style={{ border: "2px solid red" }}>
              <ResponsiveGridLayout
                className="layout"
                layouts={{ lg: rglLayout, md: rglLayout, sm: rglLayout, xs: rglLayout }}
                breakpoints={GRID_BREAKS}
                cols={GRID_COLS}
                rowHeight={ROW_HEIGHT}
                margin={[16, 16]}
                draggableHandle=".drag-handle"
                resizeHandles={["se", "sw", "ne", "nw", "e", "w", "n", "s"]}
                onDragStart={() => setIsDragging(true)}
                onDragStop={(layout) => { setIsDragging(false); commitLayout(layout); }}
                onResizeStart={() => setIsDragging(true)}
                // onResizeStop={(layout) => { setIsDragging(false); commitLayout(layout); }}
                onResizeStop={(layout, oldItem, newItem) => {
                  console.log("OLD:", oldItem);
                  console.log("NEW:", newItem);

                  setIsDragging(false);
                  commitLayout(layout);
                }}
                compactType={null}
                preventCollision={true}
                isBounded={false}
              >
                {panelsWithLayout.map((panel) => (
                  <div key={panel.id}>
                    <PanelCard
                      panel={panel}
                      results={resultsByPanel[panel.id] ?? results}
                      comparisonResults={comparisonResultsByPanel[panel.id] ?? comparisonResults}
                      loading={loading}
                      justAdded={justAddedId === panel.id}
                      onEdit={() => { setEditingPanel({ panel }); setShowBuilder(true); }}
                      onDelete={() => deletePanel(panel.id)}
                      onClone={() => clonePanel(panel)}
                      onIntervalChange={(interval) => updatePanelInterval(panel.id, interval)}
                    />
                  </div>
                ))}
              </ResponsiveGridLayout>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Panel builder modal */}
      <AnimatePresence>
        {showBuilder && (
          <PanelBuilderModal
            editingPanel={editingPanel}
            existingPanels={view?.panels ?? []}
            onClose={() => { setShowBuilder(false); setEditingPanel(null); }}
            onSave={savePanel}
            onAppendTemplate={appendTemplatePanels}
            userRole={userRole}
          />
        )}
      </AnimatePresence>

      {/* Grid-cell indicator + RGL handle/placeholder styling.
          Scoped so it doesn't leak into the rest of the app. */}
      <style>{`
        .bg-grid-indicator {
          background-image:
            linear-gradient(to right, #eef2ff 1px, transparent 1px),
            linear-gradient(to bottom, #eef2ff 1px, transparent 1px);
          background-size: calc((100% - 16px) / 12) ${ROW_HEIGHT}px;
          background-position: 8px 8px;
        }
        .react-grid-item.react-grid-placeholder {
          background: #6366f1 !important;
          opacity: 0.12 !important;
          border-radius: 16px;
        }
        .react-grid-item > .react-resizable-handle {
          opacity: 0;
          transition: opacity 0.15s;
        }
        .react-grid-item:hover > .react-resizable-handle {
          opacity: 1;
        }
        .react-grid-item.resizing {
          box-shadow: 0 0 0 2px #6366f1, 0 8px 24px rgba(99,102,241,0.18);
        }
        .react-grid-item.react-draggable-dragging {
          box-shadow: 0 12px 28px rgba(15,23,42,0.18);
          z-index: 30;
        }
      `}</style>
    </div>
  );
}