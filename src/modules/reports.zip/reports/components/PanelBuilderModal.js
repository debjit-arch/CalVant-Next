/**
 * ─────────────────────────────────────────────────────────────────────────────
 * PanelBuilderModal.jsx  (v2 — inline comparison feature)
 * ─────────────────────────────────────────────────────────────────────────────
 * Steps (new panel):
 *   -1  Template gallery   — or →
 *    0  Component type     (KPI / Chart / Target Meter)
 *    1  Data config        (module, metric, duration, comparison, benchmarks)
 *    2  Review & save
 *
 * New in v2:
 *   • Comparison toggle on Step 1 — enable a secondary date range per panel
 *     so the panel always shows current vs comparison period side-by-side.
 *     Stored as panel.comparison = { enabled, from, to } and forwarded to
 *     KpiWrapper → comparisonData.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus, Minus, GitCompareArrows } from "lucide-react";
import { AVAILABLE_EXTRACTORS } from "./dashboardSchema";

// ─── constants ────────────────────────────────────────────────────────────────

const COMPONENT_TYPES = [
  {
    category: "KPI",
    items: [
      { type: "StatCard",    label: "Stat Card",    icon: "🔢", hint: "Single number with trend indicator" },
      { type: "ScoreGauge",  label: "Score Gauge",  icon: "🎯", hint: "Circular gauge for 0–100 scores"    },
      { type: "TargetMeter", label: "Target Meter", icon: "📏", hint: "Progress bar toward a target value" },
    ],
  },
  {
    category: "Chart",
    items: [
      { type: "TrendLineChart",  label: "Line Chart", icon: "📈", hint: "Multi-series line with optional benchmarks" },
      { type: "TrendBarChart",   label: "Bar Chart",  icon: "📊", hint: "Grouped bars — great for comparisons"      },
      { type: "DonutStatusChart",label: "Donut",      icon: "🍩", hint: "Status / category breakdown"              },
    ],
  },
];

const TREND_TYPES = new Set(["TrendLineChart", "TrendBarChart"]);
const MAP_TYPES   = new Set(["DonutStatusChart", "DepartmentBreakdown"]);

const SERIES_COLORS = ["#6366f1","#ef4444","#10b981","#f59e0b","#3b82f6","#a855f7","#06b6d4","#f97316"];

const DURATION_OPTIONS = [
  { key: "createdAt",      label: "Created Time"       },
  { key: "modifiedAt",     label: "Modified Time"      },
  { key: "closedAt",       label: "Closed Time"        },
  { key: "lastActivityAt", label: "Last Activity Time" },
  { key: "unsubscribedAt", label: "Unsubscribed Time"  },
  { key: "dueAt",          label: "Due Date"           },
];

// ─── Role-based panel templates ───────────────────────────────────────────────
// Each role gets a curated set of templates that match their actual job focus.
// CISO / root / super_admin → full security posture view
// DPO                       → privacy & data protection focus
// AIO (AI Officer)          → AI impact assessments focus
// audit_manager             → audit findings & task closures
// risk_manager              → risk heat map & open risk focus
// department_user / default → their own tasks & compliance score only
//
// Templates marked `roles: ["all"]` appear for every role.

const TEMPLATES_BY_ROLE = {

  // ── CISO · root · super_admin ─────────────────────────────────────────────
  // Needs the full security posture: risk exposure, compliance score across
  // frameworks, open audit findings, overdue tasks, AI risk surface.
  ciso: [
    {
      id: "tpl_ciso_executive",
      label: "Executive Security Posture",
      icon: "🛡️",
      description: "Board-ready: compliance %, open risks, overdue items at a glance",
      panels: [
        { componentType: "StatCard",    title: "Compliance Score",        props: { extractor: "compliance.compliancePercentage" } },
        { componentType: "StatCard",    title: "Controls Implemented",    props: { extractor: "compliance.implementedControls" } },
        { componentType: "StatCard",    title: "Risks · Open",            props: { extractor: "risks.byStatus.Open" } },
        { componentType: "StatCard",    title: "Risks · Avg Score",       props: { extractor: "risks.avgScore" } },
        { componentType: "StatCard",    title: "Audits · Open Findings",  props: { extractor: "audit.totalFindings" } },
        { componentType: "StatCard",    title: "Tasks · Overdue",         props: { extractor: "tasks.overdue" } },
        { componentType: "TrendLineChart", title: "Risk & Compliance Trend", props: {
            series: [
              { key: "compliance", label: "Compliance %",  extractor: "compliance.compliancePercentage", color: "#10b981" },
              { key: "risks",      label: "Open Risks",    extractor: "risks.byStatus.Open",             color: "#ef4444" },
            ],
          },
        },
        { componentType: "DonutStatusChart", title: "Risk Status Breakdown", props: { extractor: "risks.byStatus" } },
      ],
    },
    {
      id: "tpl_ciso_framework",
      label: "Framework Coverage",
      icon: "🧩",
      description: "ISO 27001 / 27701 / 42001 control implementation depth",
      panels: [
        { componentType: "StatCard",    title: "Total Controls",          props: { extractor: "compliance.totalControls" } },
        { componentType: "StatCard",    title: "Applicable Controls",     props: { extractor: "compliance.applicableControls" } },
        { componentType: "StatCard",    title: "Auto-Compliant Controls", props: { extractor: "compliance.autoCompliantControls" } },
        { componentType: "StatCard",    title: "Manual-Compliant Controls",props: { extractor: "compliance.manualCompliantControls" } },
        { componentType: "TrendLineChart", title: "Compliance % Over Time", props: {
            series: [
              { key: "pct", label: "Compliance %", extractor: "compliance.compliancePercentage", color: "#6366f1" },
            ],
          },
        },
        { componentType: "DonutStatusChart", title: "Audit Status",       props: { extractor: "audit.byStatus" } },
      ],
    },
    {
      id: "tpl_ciso_risk_heat",
      label: "Risk Heat Map",
      icon: "🔥",
      description: "Risk depth: score distribution, open vs closed, by department",
      panels: [
        { componentType: "StatCard",         title: "Max Risk Score",        props: { extractor: "risks.maxScore" } },
        { componentType: "StatCard",         title: "Avg Risk Score",        props: { extractor: "risks.avgScore" } },
        { componentType: "StatCard",         title: "Total Risks",           props: { extractor: "risks.total" } },
        { componentType: "DonutStatusChart", title: "Risks by Status",       props: { extractor: "risks.byStatus" } },
        { componentType: "DonutStatusChart", title: "Risks by Department",   props: { extractor: "risks.byDepartment" } },
        { componentType: "TrendLineChart",   title: "Risk Score Trend",      props: {
            series: [
              { key: "avg", label: "Avg Score", extractor: "risks.avgScore", color: "#f97316" },
              { key: "max", label: "Max Score", extractor: "risks.maxScore", color: "#ef4444" },
            ],
          },
        },
      ],
    },
  ],

  // ── DPO (Data Protection Officer) ─────────────────────────────────────────
  // Cares about DPIAs, document approvals, GDPR-relevant tasks, privacy risks.
  dpo: [
    {
      id: "tpl_dpo_privacy_overview",
      label: "Privacy Command Centre",
      icon: "🔒",
      description: "DPIA pipeline, pending docs, privacy-related risks at a glance",
      panels: [
        { componentType: "StatCard",    title: "DPIAs · Total",           props: { extractor: "dpia.total" } },
        { componentType: "StatCard",    title: "DPIAs · Avg Completion",  props: { extractor: "dpia.avgCompletion" } },
        { componentType: "StatCard",    title: "Documents · Pending Approval", props: { extractor: "documents.pendingApproval" } },
        { componentType: "StatCard",    title: "Documents · Approved",    props: { extractor: "documents.approved" } },
        { componentType: "StatCard",    title: "Compliance Score",        props: { extractor: "compliance.compliancePercentage" } },
        { componentType: "StatCard",    title: "Tasks · Overdue",         props: { extractor: "tasks.overdue" } },
        { componentType: "DonutStatusChart", title: "DPIA Status",        props: { extractor: "dpia.byStatus" } },
        { componentType: "TrendLineChart",   title: "DPIA & Docs Trend",  props: {
            series: [
              { key: "dpias", label: "DPIAs",             extractor: "dpia.total",                  color: "#8b5cf6" },
              { key: "docs",  label: "Docs Pending",      extractor: "documents.pendingApproval",   color: "#f59e0b" },
            ],
          },
        },
      ],
    },
    {
      id: "tpl_dpo_document_health",
      label: "Document Health",
      icon: "📄",
      description: "Approval pipeline and document coverage across frameworks",
      panels: [
        { componentType: "StatCard",         title: "Total Documents",         props: { extractor: "documents.total" } },
        { componentType: "StatCard",         title: "Approved Documents",      props: { extractor: "documents.approved" } },
        { componentType: "StatCard",         title: "Pending Approval",        props: { extractor: "documents.pendingApproval" } },
        { componentType: "TrendLineChart",   title: "Document Approval Trend", props: {
            series: [
              { key: "approved", label: "Approved",        extractor: "documents.approved",          color: "#10b981" },
              { key: "pending",  label: "Pending",         extractor: "documents.pendingApproval",   color: "#f59e0b" },
            ],
          },
        },
        { componentType: "DonutStatusChart", title: "Task Status",             props: { extractor: "tasks.byStatus" } },
      ],
    },
  ],

  // ── AIO (AI Officer) ──────────────────────────────────────────────────────
  // Focused entirely on AI Impact Assessments (AIIA), ISO 42001 compliance,
  // and AI-related risks.
  aio: [
    {
      id: "tpl_aio_ai_overview",
      label: "AI Governance Overview",
      icon: "🤖",
      description: "Stage 1 & 2 AIIA pipeline, ISO 42001 compliance, AI risk exposure",
      panels: [
        { componentType: "StatCard",    title: "AIIA · Stage 1 Total",    props: { extractor: "aiia.stage1Total" } },
        { componentType: "StatCard",    title: "AIIA · Stage 1 Completed",props: { extractor: "aiia.stage1Completed" } },
        { componentType: "StatCard",    title: "AIIA · Stage 2 Total",    props: { extractor: "aiia.stage2Total" } },
        { componentType: "StatCard",    title: "AIIA · Stage 2 Completed",props: { extractor: "aiia.stage2Completed" } },
        { componentType: "StatCard",    title: "Compliance Score",        props: { extractor: "compliance.compliancePercentage" } },
        { componentType: "StatCard",    title: "Risks · Open",            props: { extractor: "risks.byStatus.Open" } },
        { componentType: "TrendLineChart", title: "AIIA Progress Trend",  props: {
            series: [
              { key: "s1", label: "Stage 1 Done", extractor: "aiia.stage1Completed", color: "#6366f1" },
              { key: "s2", label: "Stage 2 Done", extractor: "aiia.stage2Completed", color: "#10b981" },
            ],
          },
        },
        { componentType: "DonutStatusChart", title: "Risks by Status",    props: { extractor: "risks.byStatus" } },
      ],
    },
    {
      id: "tpl_aio_aiia_pipeline",
      label: "AIIA Pipeline Detail",
      icon: "🔬",
      description: "Draft vs assigned vs completed across both AIIA stages",
      panels: [
        { componentType: "StatCard",         title: "Stage 1 · Draft",     props: { extractor: "aiia.stage1Draft" } },
        { componentType: "StatCard",         title: "Stage 1 · Completed", props: { extractor: "aiia.stage1Completed" } },
        { componentType: "StatCard",         title: "Stage 2 · Assigned",  props: { extractor: "aiia.stage2Assigned" } },
        { componentType: "StatCard",         title: "Stage 2 · Completed", props: { extractor: "aiia.stage2Completed" } },
        { componentType: "TrendLineChart",   title: "Full AIIA Trend",     props: {
            series: [
              { key: "s1t", label: "S1 Total",  extractor: "aiia.stage1Total",     color: "#6366f1" },
              { key: "s2t", label: "S2 Total",  extractor: "aiia.stage2Total",     color: "#3b82f6" },
              { key: "s1c", label: "S1 Done",   extractor: "aiia.stage1Completed", color: "#10b981" },
              { key: "s2c", label: "S2 Done",   extractor: "aiia.stage2Completed", color: "#06b6d4" },
            ],
          },
        },
      ],
    },
  ],

  // ── Audit Manager ─────────────────────────────────────────────────────────
  audit_manager: [
    {
      id: "tpl_audit_overview",
      label: "Audit Programme Overview",
      icon: "🔍",
      description: "Audit pipeline status, findings count, and task closure rate",
      panels: [
        { componentType: "StatCard",         title: "Audits · Total",      props: { extractor: "audit.total" } },
        { componentType: "StatCard",         title: "Total Findings",      props: { extractor: "audit.totalFindings" } },
        { componentType: "StatCard",         title: "Tasks · Overdue",     props: { extractor: "tasks.overdue" } },
        { componentType: "StatCard",         title: "Tasks · Total",       props: { extractor: "tasks.total" } },
        { componentType: "DonutStatusChart", title: "Audit Status",        props: { extractor: "audit.byStatus" } },
        { componentType: "DonutStatusChart", title: "Task Status",         props: { extractor: "tasks.byStatus" } },
        { componentType: "TrendLineChart",   title: "Audit & Task Trend",  props: {
            series: [
              { key: "audits",   label: "Audits",         extractor: "audit.total",       color: "#f59e0b" },
              { key: "findings", label: "Findings",       extractor: "audit.totalFindings",color: "#ef4444" },
              { key: "overdue",  label: "Tasks Overdue",  extractor: "tasks.overdue",     color: "#f97316" },
            ],
          },
        },
      ],
    },
  ],

  // ── Risk Manager ──────────────────────────────────────────────────────────
  risk_manager: [
    {
      id: "tpl_risk_manager_overview",
      label: "Risk Register Overview",
      icon: "⚠️",
      description: "Open risks, score distribution, department breakdown",
      panels: [
        { componentType: "StatCard",         title: "Total Risks",         props: { extractor: "risks.total" } },
        { componentType: "StatCard",         title: "Open Risks",          props: { extractor: "risks.byStatus.Open" } },
        { componentType: "StatCard",         title: "Avg Risk Score",      props: { extractor: "risks.avgScore" } },
        { componentType: "StatCard",         title: "Max Risk Score",      props: { extractor: "risks.maxScore" } },
        { componentType: "DonutStatusChart", title: "Risk Status",         props: { extractor: "risks.byStatus" } },
        { componentType: "DonutStatusChart", title: "Risks by Department", props: { extractor: "risks.byDepartment" } },
        { componentType: "TrendLineChart",   title: "Risk Score Trend",    props: {
            series: [
              { key: "open", label: "Open Risks", extractor: "risks.byStatus.Open", color: "#ef4444" },
              { key: "avg",  label: "Avg Score",  extractor: "risks.avgScore",      color: "#f97316" },
            ],
          },
        },
      ],
    },
  ],

  // ── Department User (default / least privilege) ───────────────────────────
  // Only sees their own task load and the org's top-level compliance score.
  department_user: [
    {
      id: "tpl_dept_my_workload",
      label: "My Workload",
      icon: "📋",
      description: "Your tasks, overdue items, and compliance score",
      panels: [
        { componentType: "StatCard",         title: "Tasks · Total",       props: { extractor: "tasks.total" } },
        { componentType: "StatCard",         title: "Tasks · Overdue",     props: { extractor: "tasks.overdue" } },
        { componentType: "StatCard",         title: "Compliance Score",    props: { extractor: "compliance.compliancePercentage" } },
        { componentType: "DonutStatusChart", title: "Task Status",         props: { extractor: "tasks.byStatus" } },
        { componentType: "TrendLineChart",   title: "My Tasks Trend",      props: {
            series: [
              { key: "total",   label: "Total Tasks",   extractor: "tasks.total",   color: "#6366f1" },
              { key: "overdue", label: "Overdue Tasks", extractor: "tasks.overdue", color: "#ef4444" },
            ],
          },
        },
      ],
    },
  ],
};

// Roles that share the CISO view (full access)
const CISO_ROLES = new Set(["ciso", "root", "super_admin", "admin"]);
const DPO_ROLES  = new Set(["dpo", "privacy_officer"]);
const AIO_ROLES  = new Set(["aio", "ai_officer"]);

function getTemplatesForRole(userRole) {
  const r = (userRole || "").toLowerCase();
  if (CISO_ROLES.has(r))         return TEMPLATES_BY_ROLE.ciso;
  if (DPO_ROLES.has(r))          return TEMPLATES_BY_ROLE.dpo;
  if (AIO_ROLES.has(r))          return TEMPLATES_BY_ROLE.aio;
  if (r === "audit_manager")     return TEMPLATES_BY_ROLE.audit_manager;
  if (r === "risk_manager")      return TEMPLATES_BY_ROLE.risk_manager;
  // Fallback for any unrecognised role
  return TEMPLATES_BY_ROLE.department_user;
}

function instantiateTemplatePanels(template) {
  const ts = Date.now();
  return template.panels.map((p, i) => ({
    id: `panel_${ts}_${i}`,
    componentType: p.componentType,
    title: p.title,
    props: p.props,
  }));
}

// Mirrors DashboardEngine's panelSignature — two panels are "the same panel"
// if they're the same component type showing the same underlying data
// field(s), regardless of generated id/title.
function panelSignature(panel) {
  const props = panel.props ?? {};
  if (Array.isArray(props.series) && props.series.length) {
    const extractors = props.series.map((s) => s.extractor).filter(Boolean).sort().join("|");
    return `${panel.componentType}::${extractors}`;
  }
  return `${panel.componentType}::${props.extractor ?? ""}`;
}

// ─── sub-components ───────────────────────────────────────────────────────────

function StepDots({ current, total }) {
  return (
    <div className="flex items-center gap-1.5">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={`h-1.5 rounded-full transition-all duration-300 ${
            i < current  ? "bg-indigo-500 w-4" :
            i === current ? "bg-indigo-400 w-6" :
            "bg-slate-200 w-4"
          }`}
        />
      ))}
    </div>
  );
}

function FieldLabel({ children, hint }) {
  return (
    <div className="mb-1.5">
      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">{children}</span>
      {hint && <span className="ml-2 text-[11px] text-slate-400 normal-case font-normal">{hint}</span>}
    </div>
  );
}

function ExtractorSelect({ value, onChange, scalarOnly = false, placeholder = "Select a data field…" }) {
  const MAP_EXTRACTORS = new Set([
    "risks.byStatus","risks.byDepartment","audit.byStatus","audit.byDepartment",
    "tasks.byStatus","tasks.byDepartment","dpia.byStatus","dpia.byDepartment",
  ]);

  const filtered = scalarOnly
    ? AVAILABLE_EXTRACTORS.filter((e) => !MAP_EXTRACTORS.has(e.extractor))
    : AVAILABLE_EXTRACTORS;

  const groups = useMemo(() => {
    const map = {};
    for (const e of filtered) {
      const mod = e.extractor.split(".")[0];
      const key = mod.charAt(0).toUpperCase() + mod.slice(1);
      if (!map[key]) map[key] = [];
      map[key].push(e);
    }
    return map;
  }, [filtered]);

  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full border border-slate-200 bg-white rounded-xl px-3 py-2.5 text-sm text-slate-700
        focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:border-indigo-400 transition-all
        cursor-pointer appearance-none
        bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 fill%3D%22none%22 viewBox%3D%220 0 20 20%22%3E%3Cpath stroke%3D%22%236b7280%22 stroke-linecap%3D%22round%22 stroke-linejoin%3D%22round%22 stroke-width%3D%221.5%22 d%3D%22m6 8 4 4 4-4%22%2F%3E%3C%2Fsvg%3E')]
        bg-[position:right_0.5rem_center] bg-[size:1.25rem] pr-8"
    >
      <option value="" disabled>{placeholder}</option>
      {Object.entries(groups).map(([mod, items]) => (
        <optgroup key={mod} label={`── ${mod}`}>
          {items.map((e) => (
            <option key={e.extractor} value={e.extractor}>{e.label}</option>
          ))}
        </optgroup>
      ))}
    </select>
  );
}

function SeriesRow({ series, index, onChange, onRemove, canRemove }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.15 }}
      className="rounded-xl border border-slate-100 bg-slate-50/80 p-3 space-y-2"
    >
      <div className="flex gap-2 items-center">
        <input
          value={series.label}
          onChange={(e) => onChange(index, "label", e.target.value)}
          placeholder="Series label"
          className="flex-1 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
        />
        <div className="relative flex items-center gap-1">
          <div className="w-6 h-6 rounded-md border-2 border-white shadow-sm cursor-pointer" style={{ backgroundColor: series.color }} />
          <input
            type="color" value={series.color}
            onChange={(e) => onChange(index, "color", e.target.value)}
            className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
          />
        </div>
        {canRemove && (
          <button
            onClick={() => onRemove(index)}
            className="w-6 h-6 rounded-full bg-rose-100 text-rose-500 hover:bg-rose-200 flex items-center justify-center text-sm font-bold"
          >
            ×
          </button>
        )}
      </div>
      <ExtractorSelect
        value={series.extractor}
        onChange={(v) => {
          onChange(index, "extractor", v);
          if (!series.key || series.key.startsWith("series")) onChange(index, "key", v.replace(/\./g, "_"));
          const found = AVAILABLE_EXTRACTORS.find((e) => e.extractor === v);
          const defaultLabel = `Series ${index + 1}`;
          if (found && (!series.label || series.label === defaultLabel || series.label === series.extractor)) {
            onChange(index, "label", found.label);
          }
        }}
        placeholder="Select data field…"
      />
    </motion.div>
  );
}

function BenchmarkRow({ bm, index, onChange, onRemove }) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="number"
        value={bm.value}
        onChange={(e) => onChange(index, "value", Number(e.target.value))}
        placeholder="Value"
        className="w-20 border border-slate-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-300 text-center bg-white"
      />
      <input
        value={bm.label}
        onChange={(e) => onChange(index, "label", e.target.value)}
        placeholder="Label (e.g. Target)"
        className="flex-1 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
      />
      <div className="relative w-7 h-7 flex-shrink-0">
        <div className="w-full h-full rounded-md border-2 border-white shadow-sm" style={{ backgroundColor: bm.color }} />
        <input type="color" value={bm.color} onChange={(e) => onChange(index, "color", e.target.value)}
          className="absolute inset-0 opacity-0 w-full h-full cursor-pointer" />
      </div>
      <button onClick={() => onRemove(index)} className="text-slate-400 hover:text-rose-500 transition-colors">
        <Minus size={13} />
      </button>
    </div>
  );
}

// ─── Comparison section ───────────────────────────────────────────────────────
function ComparisonSection({ comparison, onChange }) {
  const { enabled, from, to } = comparison;

  // Default "previous year" when first enabled
  const enable = () => {
    const d = new Date();
    const prevYear = new Date(d);
    prevYear.setFullYear(d.getFullYear() - 1);
    onChange({
      enabled: true,
      from: prevYear.toISOString().slice(0, 10),
      to: d.toISOString().slice(0, 10),
    });
  };

  return (
    <div className="rounded-xl border border-slate-100 overflow-hidden">
      {/* Toggle header */}
      <button
        type="button"
        onClick={() => enabled ? onChange({ ...comparison, enabled: false }) : enable()}
        className={`w-full flex items-center justify-between px-3.5 py-3 transition-colors ${
          enabled ? "bg-violet-50 border-b border-violet-100" : "bg-slate-50 hover:bg-slate-100"
        }`}
      >
        <div className="flex items-center gap-2">
          <GitCompareArrows size={13} className={enabled ? "text-violet-600" : "text-slate-400"} />
          <span className={`text-[11px] font-bold uppercase tracking-widest ${enabled ? "text-violet-700" : "text-slate-500"}`}>
            Comparison period
          </span>
        </div>
        {/* Toggle pill */}
        <div className={`relative w-8 h-4 rounded-full transition-colors ${enabled ? "bg-violet-500" : "bg-slate-200"}`}>
          <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all ${enabled ? "left-4" : "left-0.5"}`} />
        </div>
      </button>

      {/* Date pickers (visible when enabled) */}
      <AnimatePresence>
        {enabled && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="overflow-hidden"
          >
            <div className="px-3.5 py-3 space-y-2 bg-violet-50/40">
              <p className="text-[10px] text-slate-400">
                Show this panel's data alongside a second date window for side-by-side comparison.
              </p>
              <div className="flex gap-2 flex-wrap">
                <div className="flex-1 min-w-[120px]">
                  <label className="block text-[10px] font-semibold text-slate-400 mb-1">From</label>
                  <input
                    type="date" value={from}
                    onChange={(e) => onChange({ ...comparison, from: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-violet-300"
                  />
                </div>
                <div className="flex-1 min-w-[120px]">
                  <label className="block text-[10px] font-semibold text-slate-400 mb-1">To</label>
                  <input
                    type="date" value={to} min={from}
                    onChange={(e) => onChange({ ...comparison, to: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-violet-300"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ReviewRow({ label, value, mono }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 gap-4">
      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide flex-shrink-0">{label}</span>
      <span className={`text-xs text-slate-700 text-right ${mono ? "font-mono" : "font-medium"}`}>{value}</span>
    </div>
  );
}

// ─── main modal ───────────────────────────────────────────────────────────────
export default function PanelBuilderModal({ editingPanel = null, existingPanels = [], onClose, onSave, onAppendTemplate, userRole = "" }) {
  const isEdit = !!editingPanel;
  const ep = editingPanel?.panel ?? null;

  const [step, setStep] = useState(isEdit ? 0 : -1);
  const [chartType, setChartType] = useState(ep?.componentType ?? "");

  // Trend series
  const [series, setSeries] = useState(() => {
    if (ep?.props?.series?.length) return ep.props.series;
    return [{ key: "series1", label: "Series 1", extractor: "", color: SERIES_COLORS[0] }];
  });

  // Single / donut / gauge / target
  const [singleExtractor, setSingleExtractor] = useState(ep?.props?.extractor ?? "");
  const [targetValue,     setTargetValue]     = useState(ep?.props?.target ?? "");

  // Duration (x-axis date field)
  const [duration, setDuration] = useState(ep?.props?.duration ?? "");

  // Benchmarks for trend charts
  const [benchmarks, setBenchmarks] = useState(() => ep?.props?.benchmarks ?? []);

  // ── Comparison (per-panel) ────────────────────────────────────────────────
  const [comparison, setComparison] = useState(() => {
    if (ep?.comparison) return ep.comparison;
    const d = new Date();
    const prev = new Date(d);
    prev.setFullYear(d.getFullYear() - 1);
    return {
      enabled: false,
      from: prev.toISOString().slice(0, 10),
      to: d.toISOString().slice(0, 10),
    };
  });

  const isTrend  = TREND_TYPES.has(chartType);
  const isMap    = MAP_TYPES.has(chartType);
  const isTarget = chartType === "TargetMeter";

  const addSeries = () =>
    setSeries((prev) => [
      ...prev,
      { key: `series${prev.length + 1}`, label: `Series ${prev.length + 1}`, extractor: "", color: SERIES_COLORS[prev.length % SERIES_COLORS.length] },
    ]);

  const updateSeries  = (i, field, value) => setSeries((prev) => prev.map((s, idx) => idx === i ? { ...s, [field]: value } : s));
  const removeSeries  = (i) => setSeries((prev) => prev.filter((_, idx) => idx !== i));
  const addBenchmark  = () => setBenchmarks((prev) => [...prev, { value: 0, label: "Target", color: "#ef4444" }]);
  const updateBenchmark = (i, field, value) => setBenchmarks((prev) => prev.map((b, idx) => idx === i ? { ...b, [field]: value } : b));
  const removeBenchmark = (i) => setBenchmarks((prev) => prev.filter((_, idx) => idx !== i));

  // Validation
  const step0Valid = chartType !== "";
  const step1Valid = isTrend ? series.some((s) => s.extractor) : singleExtractor !== "";

  const totalSteps = 3;

  const [duplicateError, setDuplicateError] = useState(null);

  const handleSave = () => {
    const panelId = isEdit ? ep.id : `panel_${Date.now()}`;
    const derivedTitle = isTrend
      ? (series.find((s) => s.extractor)?.label ?? chartType)
      : (AVAILABLE_EXTRACTORS.find((e) => e.extractor === singleExtractor)?.label ?? singleExtractor);

    const props = isTrend
      ? {
          series: series.filter((s) => s.extractor && s.key),
          ...(duration ? { duration } : {}),
          ...(benchmarks.length ? { benchmarks } : {}),
        }
      : isTarget
      ? { extractor: singleExtractor, target: targetValue ? Number(targetValue) : undefined }
      : { extractor: singleExtractor };

    const panel = {
      id: panelId,
      componentType: chartType,
      title: derivedTitle,
      props,
      // Store comparison config on the panel itself
      ...(comparison.enabled ? { comparison } : {}),
    };

    // Block adding (not editing) a panel that already exists on the
    // dashboard with the same component type + data field — this is the
    // same restriction templates use, applied to the manual builder too.
    if (!isEdit) {
      const sig = panelSignature(panel);
      const isDuplicate = existingPanels.some((p) => panelSignature(p) === sig);
      if (isDuplicate) {
        setDuplicateError("A panel showing this exact data already exists on this dashboard.");
        return;
      }
    }

    onSave({ panel, isEdit, originalPanelId: ep?.id });
    onClose();
  };

  const [templateNotice, setTemplateNotice] = useState(null);

  const handleSelectTemplate = (tpl) => {
    const result = onAppendTemplate?.(instantiateTemplatePanels(tpl));
    if (result?.skippedCount > 0 && result?.addedCount === 0) {
      // Every panel in this template already exists — keep the modal open
      // and tell the person instead of silently closing on a no-op.
      setTemplateNotice(`All panels from "${tpl.label}" are already on this dashboard.`);
      return;
    }
    if (result?.skippedCount > 0) {
      setTemplateNotice(`Added ${result.addedCount} panel${result.addedCount !== 1 ? "s" : ""} from "${tpl.label}" — ${result.skippedCount} skipped as duplicate${result.skippedCount !== 1 ? "s" : ""}.`);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <motion.div
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        transition={{ type: "spring", damping: 26, stiffness: 320 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
      >
        {/* Header */}
        <div className="px-6 pt-5 pb-4 border-b border-slate-100">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h2 className="text-base font-semibold text-slate-800">
                {isEdit ? "Edit Panel" : "Add Panel"}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {step === -1 && "Start from a template or build from scratch"}
                {step === 0 && "Pick a component type"}
                {step === 1 && "Configure data, duration & comparison"}
                {step === 2 && "Review and add to dashboard"}
              </p>
            </div>
            <button onClick={onClose} className="p-1 text-slate-300 hover:text-slate-500">
              <X size={16} />
            </button>
          </div>
          {step >= 0 && <StepDots current={step} total={totalSteps} />}
        </div>

        {/* Body */}
        <div className="px-6 py-5 max-h-[62vh] overflow-y-auto space-y-4">
          <AnimatePresence mode="wait">

            {/* Step -1: Template gallery */}
            {step === -1 && (
              <motion.div key="gallery" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.15 }} className="space-y-2">
                <p className="text-[11px] text-slate-400">Templates add multiple panels at once. Panels already on your dashboard are skipped automatically.</p>
                {templateNotice && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-700">
                    {templateNotice}
                  </div>
                )}
                {/* Role label */}
                {userRole && (
                  <div className="flex items-center gap-1.5 pb-1">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Suggested for</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600 uppercase tracking-wide">
                      {userRole.replace(/_/g, " ")}
                    </span>
                  </div>
                )}
                {getTemplatesForRole(userRole).map((tpl) => (
                  <button
                    key={tpl.id}
                    onClick={() => handleSelectTemplate(tpl)}
                    className="w-full flex items-start gap-3 px-3.5 py-3 rounded-xl border-2 border-slate-150 bg-slate-50 hover:border-indigo-300 hover:bg-indigo-50 transition-all text-left"
                  >
                    <span className="text-xl leading-none mt-0.5">{tpl.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-700">{tpl.label}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{tpl.description}</p>
                      <p className="text-[10px] text-slate-400 mt-1">{tpl.panels.length} panel{tpl.panels.length !== 1 ? "s" : ""}</p>
                    </div>
                  </button>
                ))}
                <button
                  onClick={() => setStep(0)}
                  className="w-full py-2.5 rounded-xl border-2 border-dashed border-slate-200 text-xs font-semibold text-indigo-500 hover:border-indigo-300 hover:bg-indigo-50 transition-all"
                >
                  + Build a custom panel instead
                </button>
              </motion.div>
            )}

            {/* Step 0: Component type */}
            {step === 0 && (
              <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.15 }} className="space-y-4">
                {COMPONENT_TYPES.map((cat) => (
                  <div key={cat.category}>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{cat.category}</p>
                    <div className="grid grid-cols-3 gap-2">
                      {cat.items.map((c) => (
                        <button
                          key={c.type}
                          onClick={() => setChartType(c.type)}
                          className={`rounded-xl border-2 p-3 text-left transition-all ${
                            chartType === c.type
                              ? "border-indigo-500 bg-indigo-50"
                              : "border-slate-150 bg-slate-50 hover:border-indigo-200 hover:bg-indigo-50/40"
                          }`}
                        >
                          <span className="text-xl block mb-1">{c.icon}</span>
                          <p className={`text-[11px] font-bold ${chartType === c.type ? "text-indigo-700" : "text-slate-700"}`}>{c.label}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5 leading-tight">{c.hint}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </motion.div>
            )}

            {/* Step 1: Data config */}
            {step === 1 && (
              <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.15 }} className="space-y-5">

                {/* Trend: series */}
                {isTrend && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <FieldLabel hint="one line or bar per series">Data Series</FieldLabel>
                      <button onClick={addSeries} className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1">
                        <Plus size={12} /> Add
                      </button>
                    </div>
                    <AnimatePresence>
                      {series.map((s, i) => (
                        <div key={i} className="mb-2">
                          <SeriesRow series={s} index={i} onChange={updateSeries} onRemove={removeSeries} canRemove={series.length > 1} />
                        </div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}

                {/* Single / donut / gauge */}
                {!isTrend && (
                  <div>
                    <FieldLabel hint={isMap ? "object map like risks.byStatus" : "scalar e.g. risks.total"}>
                      Data field
                    </FieldLabel>
                    <ExtractorSelect value={singleExtractor} onChange={setSingleExtractor} scalarOnly={!isMap} />
                  </div>
                )}

                {/* Target value (TargetMeter only) */}
                {isTarget && (
                  <div>
                    <FieldLabel hint="the 100% / goal value">Target value</FieldLabel>
                    <input
                      type="number" min="0" value={targetValue}
                      onChange={(e) => setTargetValue(e.target.value)}
                      placeholder="e.g. 100"
                      className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300 text-slate-700 transition-all"
                    />
                  </div>
                )}

                {/* Duration (x-axis) for trend charts */}
                {isTrend && (
                  <div>
                    <FieldLabel hint="date field for x-axis">Duration field</FieldLabel>
                    <select
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="w-full border border-slate-200 bg-white rounded-xl px-3 py-2.5 text-sm text-slate-700
                        focus:outline-none focus:ring-2 focus:ring-indigo-300 transition-all cursor-pointer"
                    >
                      <option value="">Default (generated at)</option>
                      {DURATION_OPTIONS.map((d) => (
                        <option key={d.key} value={d.key}>{d.label}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Benchmarks for trend charts */}
                {isTrend && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <FieldLabel hint="reference lines on the chart">Benchmark points</FieldLabel>
                      <button onClick={addBenchmark} className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1">
                        <Plus size={12} /> Add
                      </button>
                    </div>
                    {benchmarks.length === 0 ? (
                      <p className="text-[11px] text-slate-400">No benchmarks yet — add reference lines to mark targets or thresholds.</p>
                    ) : (
                      <div className="space-y-2">
                        {benchmarks.map((bm, i) => (
                          <BenchmarkRow key={i} bm={bm} index={i} onChange={updateBenchmark} onRemove={removeBenchmark} />
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* ── Comparison period (all panel types) ── */}
                <ComparisonSection comparison={comparison} onChange={setComparison} />

              </motion.div>
            )}

            {/* Step 2: Review */}
            {step === 2 && (
              <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.15 }} className="space-y-3">
                <div className="rounded-xl bg-slate-50 border border-slate-100 divide-y divide-slate-100">
                  <ReviewRow label="Type" value={chartType} />
                  {isTrend ? (
                    <div className="px-4 py-3">
                      <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-2">Series</p>
                      {series.filter((s) => s.extractor).map((s, i) => (
                        <div key={i} className="flex items-center gap-2 mb-1.5">
                          <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: s.color }} />
                          <span className="text-xs font-medium text-slate-700">{s.label}</span>
                          <span className="text-xs text-slate-400 ml-auto font-mono">{s.extractor}</span>
                        </div>
                      ))}
                      {benchmarks.length > 0 && (
                        <>
                          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide mb-2 mt-3">Benchmarks</p>
                          {benchmarks.map((bm, i) => (
                            <div key={i} className="flex items-center gap-2 mb-1">
                              <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: bm.color }} />
                              <span className="text-xs font-medium text-slate-700">{bm.label}</span>
                              <span className="text-xs text-slate-400 ml-auto font-mono">{bm.value}</span>
                            </div>
                          ))}
                        </>
                      )}
                    </div>
                  ) : (
                    <>
                      <ReviewRow label="Extractor" value={singleExtractor} mono />
                      {isTarget && targetValue && <ReviewRow label="Target" value={targetValue} />}
                    </>
                  )}
                  {comparison.enabled && (
                    <div className="px-4 py-3 flex items-center gap-2">
                      <GitCompareArrows size={11} className="text-violet-500 flex-shrink-0" />
                      <span className="text-[11px] text-slate-500">
                        Comparison: {comparison.from} → {comparison.to}
                      </span>
                    </div>
                  )}
                </div>
                <p className="text-xs text-slate-400 text-center">
                  {isEdit ? "Your changes will be saved." : "This panel will be added to your dashboard."}
                </p>
                {duplicateError && (
                  <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-[11px] text-rose-600 text-center">
                    {duplicateError}
                  </div>
                )}
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={() => {
              setDuplicateError(null);
              if (step === -1 || (step === 0 && isEdit)) onClose();
              else if (step === 0) setStep(-1);
              else setStep(step - 1);
            }}
            className="text-sm text-slate-500 hover:text-slate-700 font-medium px-2 py-1"
          >
            {step === -1 || (isEdit && step === 0) ? "Cancel" : "← Back"}
          </button>

          {step === -1 ? null : step < 2 ? (
            <button
              onClick={() => { setDuplicateError(null); setStep(step + 1); }}
              disabled={(step === 0 && !step0Valid) || (step === 1 && !step1Valid)}
              className="px-5 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold
                hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed
                active:scale-95 transition-all shadow-sm"
            >
              Next →
            </button>
          ) : (
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold
                hover:bg-emerald-700 active:scale-95 transition-all shadow-sm flex items-center gap-2"
            >
              ✓ {isEdit ? "Save Changes" : "Add Panel"}
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}